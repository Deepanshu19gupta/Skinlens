import { ImageUpload } from "./home.js";

function App() {
  return <ImageUpload />;
}

export default App;
